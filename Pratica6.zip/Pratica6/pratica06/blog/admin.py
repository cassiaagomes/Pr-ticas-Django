from django.contrib import admin

from django.contrib import admin
from .models import Autor, Editora, Livro, Publica

admin.site.register(Autor)
admin.site.register(Editora)
admin.site.register(Livro)
admin.site.register(Publica)
